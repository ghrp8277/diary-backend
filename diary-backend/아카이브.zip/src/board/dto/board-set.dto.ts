import { BoardInterface } from '../interface/board.interface'

export class SetBoardDto implements BoardInterface {
    title: string;
    content: string;
    datetime: Date;
    image_files_path: string[];
}